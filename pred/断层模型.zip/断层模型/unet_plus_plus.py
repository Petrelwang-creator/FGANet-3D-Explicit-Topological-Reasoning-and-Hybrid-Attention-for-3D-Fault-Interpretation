# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from unet3_layers import unetConv3, ResNet18
# from .init_weights import init_weights
from functools import partial
from torch.nn import init

class ContinusParalleConv(nn.Module):
    # 一个连续的卷积模块，包含BatchNorm 在前 和 在后 两种模式
    def __init__(self, in_channels, out_channels, pre_Batch_Norm=True):
        super(ContinusParalleConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels

        if pre_Batch_Norm:
            self.Conv_forward = nn.Sequential(
                # nn.BatchNorm3d(self.in_channels),
                nn.InstanceNorm3d(self.in_channels),
                nn.ReLU(),
                nn.Conv3d(self.in_channels, self.out_channels, 3, padding=1),
                # nn.BatchNorm3d(out_channels),
                nn.InstanceNorm3d(out_channels),
                nn.ReLU(),
                nn.Conv3d(self.out_channels, self.out_channels, 3, padding=1))

        else:
            self.Conv_forward = nn.Sequential(
                nn.Conv3d(self.in_channels, self.out_channels, 3, padding=1),
                # nn.BatchNorm3d(out_channels),
                nn.InstanceNorm3d(out_channels),
                nn.ReLU(),
                nn.Conv3d(self.out_channels, self.out_channels, 3, padding=1),
                # nn.BatchNorm3d(self.out_channels),
                nn.InstanceNorm3d(self.out_channels),
                nn.ReLU())

    def forward(self, x):
        x = self.Conv_forward(x)
        return x



class UnetPlusPlus_attSE(nn.Module):
    def __init__(self, num_classes, deep_supervision=False):
        super(UnetPlusPlus_attSE, self).__init__()
        self.num_classes = num_classes
        self.deep_supervision = deep_supervision
        # UNet++ 原论文
        self.filters = [64, 128, 256, 512, 1024]
        # fault seg
        self.filters = [16, 32, 64, 512]
        # ours_b
        self.filters = [16, 32, 64, 128, 256]
        # ours_s
        self.filters = [16, 32, 64, 128]
        # our_t
        self.filters = [8, 16, 32, 64]

        # self.downblock = Dblock(64)

        self.CONV2_1 = ContinusParalleConv(32 * 2, 32, pre_Batch_Norm=True)

        self.CONV1_1 = ContinusParalleConv(16 * 2, 16, pre_Batch_Norm=True)
        self.CONV1_2 = ContinusParalleConv(16 * 3, 16, pre_Batch_Norm=True)

        self.CONV0_1 = ContinusParalleConv(8 * 2, 8, pre_Batch_Norm=True)
        self.CONV0_2 = ContinusParalleConv(8 * 3, 8, pre_Batch_Norm=True)
        self.CONV0_3 = ContinusParalleConv(8 * 4, 8, pre_Batch_Norm=True)

        self.stage_0 = ContinusParalleConv(1, 8, pre_Batch_Norm=False)
        self.stage_1 = ContinusParalleConv(8, 16, pre_Batch_Norm=False)
        self.stage_2 = ContinusParalleConv(16, 32, pre_Batch_Norm=False)
        self.stage_3 = ContinusParalleConv(32, 64, pre_Batch_Norm=False)

        self.pool = nn.MaxPool3d(2)

        self.upsample_2_1 = nn.ConvTranspose3d(in_channels=64, out_channels=32, kernel_size=4, stride=2, padding=1)

        self.upsample_1_1 = nn.ConvTranspose3d(in_channels=32, out_channels=16, kernel_size=4, stride=2, padding=1)
        self.upsample_1_2 = nn.ConvTranspose3d(in_channels=32, out_channels=16, kernel_size=4, stride=2, padding=1)

        self.upsample_0_1 = nn.ConvTranspose3d(in_channels=16, out_channels=8, kernel_size=4, stride=2, padding=1)
        self.upsample_0_2 = nn.ConvTranspose3d(in_channels=16, out_channels=8, kernel_size=4, stride=2, padding=1)
        self.upsample_0_3 = nn.ConvTranspose3d(in_channels=16, out_channels=8, kernel_size=4, stride=2, padding=1)

        # 分割头
        self.final_super_0_1 = nn.Sequential(
            # nn.BatchNorm3d(8),
            nn.InstanceNorm3d(8),
            nn.ReLU(),
            nn.Conv3d(8, self.num_classes, 3, padding=1),
        )
        self.final_super_0_2 = nn.Sequential(
            # nn.BatchNorm3d(8),
            nn.InstanceNorm3d(8),
            nn.ReLU(),
            nn.Conv3d(8, self.num_classes, 3, padding=1),
        )
        self.final_super_0_3 = nn.Sequential(
            # nn.BatchNorm3d(8),
            nn.InstanceNorm3d(8),
            nn.ReLU(),
            nn.Conv3d(8, self.num_classes, 3, padding=1),
            nn.Softmax()
        )

    def forward(self, x):
        x_0_0 = self.stage_0(x)
        x_1_0 = self.stage_1(self.pool(x_0_0))
        x_2_0 = self.stage_2(self.pool(x_1_0))
        x_3_0 = self.stage_3(self.pool(x_2_0))
        x_0_1 = torch.cat([self.upsample_0_1(x_1_0), x_0_0], 1)
        x_0_1 = self.CONV0_1(x_0_1)
        x_1_1 = torch.cat([self.upsample_1_1(x_2_0), x_1_0], 1)
        x_1_1 = self.CONV1_1(x_1_1)

        x_2_1 = torch.cat([self.upsample_2_1(x_3_0), x_2_0], 1)
        x_2_1 = self.CONV2_1(x_2_1)

        x_1_2 = torch.cat([self.upsample_1_2(x_2_1), x_1_0, x_1_1], 1)
        x_1_2 = self.CONV1_2(x_1_2)

        x_0_2 = torch.cat([self.upsample_0_2(x_1_1), x_0_0, x_0_1], 1)
        x_0_2 = self.CONV0_2(x_0_2)

        x_0_3 = torch.cat([self.upsample_0_3(x_1_2), x_0_0, x_0_1, x_0_2], 1)
        x_0_3 = self.CONV0_3(x_0_3)


        if self.deep_supervision:
            out_put1 = self.final_super_0_1(x_0_1)
            out_put2 = self.final_super_0_2(x_0_2)
            out_put3 = self.final_super_0_3(x_0_3)
            return [out_put1, out_put2, out_put3]
        else:
            return self.final_super_0_3(x_0_3)
